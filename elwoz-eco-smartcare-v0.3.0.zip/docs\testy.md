# ELWOZ ECO SmartCare – Procedura Testowa i Rejestr Weryfikacji
**Wersja:** 0.2.8 (Customer Service Intelligence: Stabilizacja silnika, obsługa limitów 15 RPM, eliminacja blokad LockService, warstwa Service API)  
**Projekt:** Studencki prototyp wdrożeniowy – Uniwersytet WSB Merito w Gdańsku  
**Przedsiębiorstwo:** ELWOZ ECO Sp. z o.o. (Rejon Kartuzy)  
**Dedykowane konto testowe:** `wsb.student.tester@gmail.com`  
**Zweryfikowany link do opinii Google:** `https://search.google.com/local/writereview?placeid=ChIJ13yCwGSa_UYRqkDdyWL8wdA`

---

## 1. Cel i zasady przeprowadzania testów

Niniejsza procedura służy do zweryfikowania poprawności działania aplikacji **ELWOZ ECO SmartCare** po wprowadzeniu stabilizacji silnika i audycie końcowym v0.2.8:
1. **Zautomatyzowany audyt silnika (`tests/test-v028-audit.js`):** 48 testów automatycznych pokrywających kolejkę AI, barierę 15 RPM, cooldown 429, parser limitów RPM/TPM/RPD, natychmiastowe przerywanie partii po 429, odzyskiwanie zawieszonych i zresetowanych zgłoszeń (w tym ELW-2026-0006), formatowanie Dashboardu (C11/D11), blokady współbieżności `tryLock`, szablony awaryjne, robocze SLA (7:00-16:00), walidację danych, kontrolę CX/PR (w tym „pacanie”, „spieprzaj dziadu”), ochronę PII oraz Service API (100% PASS, 48/48).
2. **Wyłącznie dane fikcyjne:** Żadne testowe zgłoszenie nie może zawierać rzeczywistych nazwisk, prywatnych adresów ani numerów telefonów mieszkańców Kartuz.
3. **Brak zmyślonych rezultatów:** W tabelach poniżej pola dotyczące rzeczywistych rezultatów i pomiarów czasu w interfejsie Google Sheets pozostawiono do weryfikacji w chmurze.
4. **Twarde zabezpieczenie serwerowe (Backend Whitelist Guard):** Backend bezwzględnie blokuje wysyłkę na jakikolwiek inny adres niż `wsb.student.tester@gmail.com`, a temat wiadomości zawsze otrzymuje prefiks `[TEST]`.
5. **Zasady etyczne Google Reviews:** Prośba o recenzję jest neutralna, bez nagród, bez sugerowania ocen, bez filtrowania zadowolonych/niezadowolonych mieszkańców i BEZ TEKSTU ZASTĘPCZEGO (placeholdera).
6. **Natywne Structured Outputs i filtracja thought:** Odpowiedź AI jest wymuszana w schemacie JSON, a bloki myśli modelu rozumującego są ignorowane.
7. **Wspólna ochrona limitów 15 RPM i Backoff 429:** Minimalny odstęp 4200 ms pomiędzy zapytaniami oraz 60-sekundowy cooldown po HTTP 429.

### Rejestr zestawów testów automatycznych (`tests/test-v028-audit.js`):
- **SUITE 1: Automatyczna kolejka AI i Rate Limiting** (14/14 PASS): Minimalny odstęp 4200 ms, 429 backoff cooldown (60s), wspólna bariera dla `polishMessageWithAiDirect`, nieblokująca rejestracja podczas cooldownu, limit 3 prób na zgłoszenie, odzyskiwanie zawieszonych analiz (>10 min), atomowa rezerwacja per-ticket `tryAcquireTicketAiLock`, unikalny wyzwalacz czasowy (5 min), trwałe odzyskiwanie arkusza po ID, zgodność LockService z GAS (`tryLock` boolean, `waitLock` void/throw), parser limitów RPM/TPM/RPD (`parseGeminiQuotaError`), przerwanie partii przy 429 bez zużywania prób i bez fałszywych sukcesów, odzyskanie i odblokowanie `ELW-2026-0006` z zachowaniem historii błędów (`recoverAndResetAiQueue`), formatowanie liczb całkowitych w Dashboardzie (C11, D11) i nagłówek v0.2.8.
- **SUITE 2: Rejestracja zgłoszeń & Reconciliation Lock Race** (3/3 PASS): Pobieranie ID pod blokadą bez nadpisywania, brak spamu e-mail dla zgłoszeń z przeszłości, natychmiastowe zwalnianie blokady `LockService` w bloku `finally`.
- **SUITE 3: Komunikacja i Szablony Awaryjne** (7/7 PASS): Oddzielenie poufnych notatek pracownika od korespondencji z mieszkańcem, szablon pochwały bez GPS i niepotwierdzonego kierownika, szablon niekompletny, szablon reklamacji bez niepotwierdzonego dyspozytora, ochrona przed błędnym szkicem CRM, serwerowa walidacja jakości treści (`validateMessageContentQuality`), blokada przypadków „pacanie” i „spieprzaj dziadu”.
- **SUITE 4: Priorytety i Robocze SLA (7:00-16:00)** (5/5 PASS): Pomijanie nocy i weekendów w SLA, start spraw weekendowych w poniedziałek o 7:00, ochrona ręcznie zatwierdzonego priorytetu pracownika (`PRIORITY_APPROVED`), brak fałszywego przeterminowania przy terminowym 1. kontakcie, odróżnienie wskaźników 1. reakcji i kolejnego kroku.
- **SUITE 5: Walidacja danych i Edge Cases** (7/7 PASS): Odrzucenie 'niewiadoma' jako ulicy, wykrywanie braku miejscowości, niewrażliwość na wielkość liter frakcji, wykrywanie wielokrotności i fetoru, opcjonalność kontaktu, elastyczny parser dat (dwucyfrowe, separatory przecinkowe).
- **SUITE 6: Ochrona danych osobowych (PII) i Kontrola Jakości** (4/4 PASS): Lokalne maskowanie danych identyfikacyjnych, blokada AI przy danych wysokiego ryzyka (karty/dowody), ścisła biała lista e-mail, serwerowa blokada agresywnych wiadomości.
- **SUITE 7: Warstwa Service API** (8/8 PASS): Blokada statusu Rozwiązane bez sposobu załatwienia, brak nadpisywania daty rozwiązania, utrwalanie zatwierdzonego priorytetu, odróżnienie aktywnej zaległości od historycznego naruszenia SLA, walidacja obiektów Date dla kolejnego kroku i pracownika, precyzyjne kody błędów AI, blokowanie ręcznej analizy w `apiTriggerAiAnalysis`, blokowanie ręcznej analizy w `processAiTicketAnalysis`.

---

## 2. Scenariusze testowe

| ID | Scenariusz testowy | Dane wejściowe / Akcja | Oczekiwany rezultat | Rzeczywisty rezultat | Status testu | Osoba testująca i data | Uwagi i poprawki |
|---|---|---|---|---|---|---|---|
| **TEST-01** | **Przygotowanie potwierdzenia przyjęcia zgłoszenia** | Wybór z menu: *SmartCare -> Przygotuj potwierdzenie przyjęcia* dla zaznaczonego wiersza z adresem e-mail. | Wyświetla się okno dialogowe z uzupełnionym szablonem A (nr zgłoszenia, lokalizacja, frakcja, informacja o weryfikacji przez dyspozytornię POK Kartuzy). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-02** | **Edycja wiadomości przed wysyłką** | Zmiana treści i tematu w oknie dialogowym przed kliknięciem przycisku *Zatwierdź i wyślij*. | Zmiany wprowadzone przez pracownika są uwzględnione w wysyłanej wiadomości i zapisane w historii; brak wysyłki bez zgody. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-03** | **Wysyłka na dedykowany adres testowy (wsb.student.tester@gmail.com)** | Wysłanie wiadomości w aktywnym trybie demonstracyjnym (`USTAWIENIA: TAK`). | Wiadomość trafia WYŁĄCZNIE na `wsb.student.tester@gmail.com`; temat zawiera `[TEST]`; stopka informuje o demonstracji studenckiej WSB Merito. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-04** | **Zapis historii wysyłki w HISTORIA KOMUNIKACJI** | Wysłanie wiadomości e-mail do zgłoszenia. | W zakładce `HISTORIA KOMUNIKACJI` pojawia się nowy wiersz ze statusem `wysłano`, pełną treścią, datą i loginem pracownika. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-05** | **Obsługa zgłoszenia bez adresu e-mail** | Próba przygotowania wiadomości dla zgłoszenia, gdzie pole e-mail jest puste. | System wyświetla monit o braku e-maila; jeśli dostępny jest telefon, pyta o zarejestrowanie kontaktu telefonicznego. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-06** | **Odnotowanie kontaktu telefonicznego** | Wybór z menu: *SmartCare -> Odnotuj kontakt telefoniczny*, wpisanie wyniku i notatki. | Zapis w `HISTORIA KOMUNIKACJI` ze statusem `odnotowano kontakt`; aktualizacja pola `Data ostatniego kontaktu` i `Wynik kontaktu` w `ZGŁOSZENIA`. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-07** | **Przygotowanie informacji o rozwiązaniu problemu** | Próba wybrania *Przygotuj informację o rozwiązaniu*, gdy pole `Sposób rozwiązania sprawy` jest puste. | System blokuje przygotowanie wiadomości i wyświetla monit o konieczności wpisania rzeczywistych działań naprawczych w arkuszu. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-08** | **Weryfikacja linku do opinii Google** | Wybór *Przygotuj prośbę o opinię* przy braku zweryfikowanego adresu URL w `USTAWIENIA`. | System blokuje operację; informuje o zakazie wysyłki prośby z tekstem zastępczym (placeholderem); brak oznaczania w CRM. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-09** | **Zapis oceny satysfakcji mieszkańca (1–5)** | Wpisanie oceny w kolumnie `Ocena satysfakcji (1-5)` w `ZGŁOSZENIA`. | Formuła w `DASHBOARD` aktualizuje średnią ocenę oraz liczbę zebranych ocen; ocena nie jest wymagana do zamknięcia zgłoszenia. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-10** | **Zabezpieczenie przed ponowną prośbą o opinię** | Próba wysłania prośby o opinię do zgłoszenia, które ma już wartość `Prośba o opinię wysłana = TAK`. | Wyświetla się ostrzeżenie informujące, że prośba została już przekazana; wysyłka wymaga świadomego potwierdzenia. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-11** | **Twarda blokada serwerowa wysyłki na inny adres niż wsb.student.tester@gmail.com** | Próba wymuszenia wysyłki na obcy adres. | Backend (`processSendEmail`) bezwzględnie zwraca błąd, nie zamyka okna dialogowego, odnotowuje próbę jako błąd i chroni przed wysyłką zewnętrzną. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-12** | **Obsługa błędów wysyłki i brak zamykania modala** | Wystąpienie błędu serwera podczas wysyłki e-mail. | Klient (`showEmailComposer`) nie zamyka okna wiadomości; wyświetla czytelny komunikat błędu; pracownik może poprawić treść. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-13** | **Zabezpieczenie współbieżności LockService** | Równoczesna rejestracja formularza i generowanie ID zgłoszenia. | `LockService` kolejkuje operacje; trwały licznik `LAST_ASSIGNED_TICKET_ID` gwarantuje brak kolizji identyfikatorów. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-14** | **Obliczanie KPI w godzinach (Dashboard)** | Zgłoszenie z różnicą dat np. 2 godziny 30 minut. | Formuła `DASHBOARD` (komórki C8, D8) zwraca `2.50` godz. (dokładność do dwóch miejsc po przecinku, brak błędu INT()). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-15** | **Odsetek próśb o opinię wyłącznie wśród zakończonych** | 10 zgłoszeń (5 nowych, 5 rozwiązanych; 2 z wysłaną prośbą). | Komórka C11 zwraca `40%` (2/5), a nie 20% (2/10). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-16** | **Współbieżna rejestracja zgłoszeń pod LockService (<200ms)** | Złożenie 2 zgłoszeń z formularza Google Forms w tym samym czasie. | Oba zgłoszenia natychmiast otrzymują kolejne unikalne ID (`ELW-2026-XXXX`), status 'Nowe' i termin SLA; brak timeoutu 30s; wysyłka e-mail i AI działają w tle. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-17** | **Automatyczne przywracanie pominiętych zgłoszeń (`reconcileUnprocessedFormResponses`)** | Wybór z menu: *SmartCare -> Wykryj i uzupełnij brakujące zgłoszenia* w arkuszu z nieprzetworzonym wierszem (np. zgłoszenie z 26.11.2026, 10:42:11). | System nadaje kolejny numer ID, ustawia status 'Nowe', priorytet 'STANDARDOWY', SLA (4h od daty zgłoszenia) i kieruje do kolejki AI bez ponownej wysyłki historycznych e-maili. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-18** | **Obsługa alfanumerycznych numerów posesji (`isHouseNumberPresent`)** | Zgłoszenia z numerami posesji `4C`, `12A`, `1/2`, `3B/4`, `24` (np. `ELW-2026-0006`, `ELW-2026-0007`, `ELW-2026-0009`). | System nie zgłasza błędu 'Brak numeru posesji'; pre-walidacja potwierdza kompletność adresu; prompt AI otrzymuje status 'KOMPLETNY'; AI nie dopytuje o adres. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-19** | **Przetwarzanie kolejki AI z ochroną limitu 15 RPM (`processAiAnalysisQueue`)** | Wybór z menu: *SmartCare -> Przetwórz kolejkę AI* dla zgłoszeń ze statusem 'Oczekuje' lub 'Błąd'. | Skrypt przetwarza zgłoszenia z 2-sekundowym odstępem; przy błędzie API zapisuje czytelny komunikat w kolumnie `Szczegóły błędu AI`; brak fałszowania szablonem zastępczym. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-20** | **Obsługa kategorii Pochwała/Podziękowanie (standard CX/PR)** | Zgłoszenie z kategorią Pochwała (np. podziękowanie za miłą załogę). | Model sugeruje priorytet 'NISKI', rekomendowane działanie to wpis do rejestru wyróżnień i podziękowanie załodze; bezwzględny brak weryfikacji GPS śmieciarki! | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-21** | **Weryfikacja warstwy Service API dla aplikacji webowej v0.3.0** | Wywołanie funkcji `apiGetTicketsList()`, `apiGetDashboardStats()`, `apiUpdateTicket()`. | Funkcje zwracają czyste obiekty JSON; brak zależności od aktywnego zaznaczenia w arkuszu; bezpieczne modyfikacje pod LockService. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-16** | **Interaktywna weryfikacja danych dla AI (Human-in-the-Loop)** | Wybór z menu: *SmartCare -> Analizuj zgłoszenie przez AI*. | Wyświetla się okno dialogowe z oczyszczonym opisem (brak ulicy, posesji, nazwiska); pracownik może zmodyfikować treść przed wysłaniem do modelu Gemini Flash. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-17** | **Natywne Structured Outputs i eliminacja błędu myśli (thought)** | Kliknięcie *Wyślij do AI (Przeanalizuj)* w oknie weryfikacji. | Część `thought` jest ignorowana; poprawny obiekt JSON trafia do walidacji; brak błędu `SyntaxError: Unexpected token 'o'`; CRM zostaje uzupełniony. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-18** | **Obsługa błędów analizy AI i brak zamykania okna** | Symulacja błędu sieci, limitu quota lub niepoprawnych danych. | Okno dialogowe weryfikacji AI pozostaje otwarte; wyświetla się czytelny komunikat; przycisk zmienia stan na `🤖 Ponów analizę AI`. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-19** | **Samodzielny test diagnostyczny Gemini API z menu SmartCare** | Wybór z menu: *SmartCare -> 🔍 Test diagnostyczny Gemini API*. | Wyświetla się okno modalne z pełną diagnostyką: nazwa modelu Flash, HTTP 200, finishReason: STOP, liczba części thought (odfiltrowane), zużycie tokenów (prompt, candidates, thinking) oraz podgląd sparsowanego JSON. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-20** | **Weryfikacja puli 8192 tokenów i eliminacja błędu braku klamer JSON** | Analiza zgłoszeń ELW-2026-0001 i ELW-2026-0002 przez Gemini Flash. | Brak błędu obcięcia tokenów; model generuje kompletny JSON ze wszystkimi wymaganymi polami; pola CRM w arkuszu ZGŁOSZENIA zostają poprawnie wypełnione. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-21** | **Dynamiczny Dashboard i eliminacja błędu #ERROR!** | Przeliczenie statystyk dla 3 istniejących zgłoszeń (total = 3, kategorie = 1 każda, 1 rozwiązane). | Komórka C5 wyświetla `3`, kategorie w kolumnie C wyświetlają `1`, brak błędów `#ERROR!`; wygenerowane 2 czytelne wykresy (kategorii i statusów). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-22** | **Automatyczne powiadomienia e-mail o nowym zgłoszeniu** | Wysłanie nowego zgłoszenia przez formularz Google Forms. | Wyzwalacz `handleNewTicketSubmit` wysyła e-mail z powiadomieniem na `wsb.student.tester@gmail.com`; zdarzenie odnotowane w `HISTORIA KOMUNIKACJI`. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-23** | **Blokada przycisków i status w oknie edycji wiadomości** | Kliknięcie *Usprawnij styl z AI* w oknie przygotowania wiadomości. | Przycisk *Zatwierdź i wyślij* zostaje zablokowany; wyświetla się komunikat `AI przygotowuje odpowiedź…`; po zakończeniu przyciski odblokowują się, a treść można edytować. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-24** | **Weryfikacja standardów PR i CX w stylizacji AI** | Przekazanie do stylizacji roboczej notatki zawierającej wzmianki o naganach kierowcy lub fikcyjnych trasach. | Model usuwa wzmianki o karach i fikcyjnych faktach, stosuje powitanie *Dzień dobry,*, dziękuje za kontakt i przeprasza za utrudnienia, zachowując oficjalne dane POK. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-25** | **Jednoklikowa aktualizacja systemu do v0.2.7** | Wybór z menu: *SmartCare -> 🚀 Aktualizuj system do v0.2.7*. | Skrypt idempotentnie aktualizuje strukturę CRM o nowe kolumny CSI, formatowanie warunkowe 4 priorytetów, parametry USTAWIENIA oraz wskaźniki Dashboardu. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-26** | **Scenariusz A: Niekompletny adres i rozbieżność frakcji** | Wprowadzenie zgłoszenia braku odbioru bez numeru posesji oraz z zaznaczoną frakcją BIO, podczas gdy opis dotyczy plastiku. | Lokalna kontrola danych wykrywa brak numeru posesji oraz rozbieżność frakcji; AI przygotowuje pytania uzupełniające w propozycji odpowiedzi; stan AI: *Wymaga weryfikacji*; strona odpowiedzialna: *Mieszkaniec*. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-27** | **Scenariusz B: Powtarzający się problem (rekomendacja PILNY)** | Zgłoszenie z opisem: *„Pojemnik nieodebrany po raz kolejny, bioodpady gniją na słońcu i zalegają od 2 tygodni”*. | AI wykrywa powtarzalność problemu i fetor; rekomenduje priorytet `PILNY` z uzasadnieniem; system ustawia termin SLA 1. reakcji na 15 minut. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-28** | **Scenariusz C: Zwykła pochwała lub sugestia** | Wprowadzenie pochwały pracy załogi lub prośby o harmonogram bez numeru posesji. | Lokalna kontrola danych nie wymaga numeru posesji dla kategorii Pochwała/Sugestia; AI proponuje podziękowanie i zamyka sprawę bez zbędnych pytań; priorytet `NISKI` (24h). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-29** | **Scenariusz D: Zgłoszenie kompletne z gotową 1. odpowiedzią w 0s** | Wprowadzenie kompletnego zgłoszenia ze wszystkimi polami i adresem e-mail. | AI w tle generuje kompletną pierwszą odpowiedź w CRM; po otwarciu kreatora odpowiedzi treść ładuje się natychmiast (0 sekund oczekiwania pracownika). | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-30** | **Scenariusz E: Zaplanowane działanie na jutro (sprawa w toku)** | Wpisanie w panelu: *„Zaplanowano podjazd kontrolny śmieciarki na jutro rano”*. | Sprawa nie zostaje przedwcześnie oznaczona jako rozwiązana; status pozostaje *W realizacji*, z określonym terminem następnego działania. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-31** | **Scenariusz F: Sprawa przeterminowana SLA** | Brak reakcji na zgłoszenie PILNY po upływie 15 minut. | Procedura SLA wykrywa przekroczenie czasu; pole `Przekroczenie SLA` przyjmuje wartość `TAK`; Dashboard zwiększa licznik przeterminowanych spraw. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-32** | **Scenariusz G: Sprawa bez zaplanowanego kolejnego kroku** | Zgłoszenie w statusie *W realizacji* lub *Do weryfikacji* z pustym polem `Następne działanie`. | Dashboard i Przeglądarka Kolejki natychmiast filtrują i wyróżniają sprawę czerwoną etykietą *Brak przypisanego kroku*. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-33** | **Scenariusz H: Zgłoszenie z danymi osobowymi (filtr PII)** | Mieszkaniec wkleja w opisie swój numer PESEL i prywatny numer telefonu. | Lokalny filtr PII maskuje wrażliwe dane przed wysłaniem do modelu; w CRM zapisywana jest flaga w lokalnej kontroli danych; dane nie wyciekają do AI. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-34** | **Scenariusz I: Obsługa limitu API / tryb offline (Fallback)** | Symulacja braku klucza API Gemini lub błędu sieci/limitu quota. | System nie blokuje przyjęcia zgłoszenia do CRM ani powiadomień e-mail; podstawia bezpieczny szablon roboczy; stan AI przyjmuje wartość *Wymaga weryfikacji* lub *Błąd*. | *(do uzupełnienia po teście)* | `Do wykonania` | | |
| **TEST-35** | **Scenariusz J: Jednoczesne wpłynięcie kilku zgłoszeń (LockService)** | Wysłanie 3 zgłoszeń z formularza w tym samym momencie. | `LockService` kolejkuje zapisy; każde zgłoszenie otrzymuje kolejny unikalny identyfikator (`ELW-2026-XXXX`); brak kolizji i nadpisań w arkuszu. | *(do uzupełnienia po teście)* | `Do wykonania` | | |

---

## 3. Tabela porównania czasu obsługi zgłoszenia (Badanie efektywności AI)

> [!NOTE]
> Pomiary czasu zostaną zarejestrowane przez członków zespołu w minutach dla próby rzeczywistych zgłoszeń testowych.

| Etap obsługi zgłoszenia | Czas tradycyjny (bez AI) [min] | Czas ze wsparciem AI [min] | Oszczędność czasu [%] | Ocena jakości odpowiedzi (skala 1–5) | Uwagi i spostrzeżenia zespołu |
|---|:---:|:---:|:---:|:---:|---|
| **1. Kategoryzacja i wstępna weryfikacja opisu** | *(pomiar w toku)* | *(pomiar w toku)* | *(do obliczenia)* | *(ocena zespołu)* | Przypisanie do frakcji i wagi sprawy |
| **2. Wykrycie brakujących danych w zgłoszeniu** | *(pomiar w toku)* | *(pomiar w toku)* | *(do obliczenia)* | *(ocena zespołu)* | Analiza kompletności (np. brak numeru kubła) |
| **3. Przygotowanie potwierdzenia przyjęcia sprawy** | *(pomiar w toku)* | *(pomiar w toku)* | *(do obliczenia)* | *(ocena zespołu)* | Wypełnienie szablonu A z danymi |
| **4. Przygotowanie informacji o rozwiązaniu i prośby o opinię** | *(pomiar w toku)* | *(pomiar w toku)* | *(do obliczenia)* | *(ocena zespołu)* | Zredagowanie notatki i neutralnego zaproszenia |
| **ŁĄCZNY CZAS OBSŁUGI JEDNEGO ZGŁOSZENIA:** | **—** | **—** | **—** | **—** | **Syntetyczny wynik badania efektywności** |

---

## 4. Wytyczne audytu i weryfikacji przez zespół

1. Wszystkie operacje testowe wykonujemy z poziomu dedykowanego konta Google: `wsb.student.tester@gmail.com`.
2. Każdy zrealizowany test należy oznaczyć statusem `Zaliczony` lub `Niezaliczony`.
3. W kolumnie `Rzeczywisty rezultat` należy opisać faktyczne zachowanie systemu podczas testu.
4. Wszelkie uwagi i spostrzeżenia należy zarejestrować w kolumnie `Uwagi`.

---

## 5. Zautomatyzowany Rejestr Testów Audytowych v0.2.8 (`tests/test-v028-audit.js`)

W odpowiedzi na niezależny audyt kodu zaimplementowano pełny zestaw 33 testów automatycznych weryfikujących poprawność algorytmów silnika. Wszystkie testy są uruchamiane lokalnie w piaskownicy Node.js z atrapami usług Apps Script:

```bash
node tests/test-v028-audit.js
```

### Wyniki wykonania testów audytowych:

| Moduł / Grupa audytowa | Liczba testów | Status | Kluczowe weryfikowane aspekty |
|---|:---:|:---:|---|
| **SUITE 1: Automatyczna kolejka AI i Rate Limiting** | 7 | **PASS (7/7)** | Minimalny odstęp 4200 ms (15 RPM), 60s 429 Cooldown backoff, limit 3 prób na ticket, reset zgłoszeń "W trakcie" >10 min, concurrency lock, unikalność wyzwalacza czasowego, odzyskiwanie arkusza przez `SMARTCARE_SPREADSHEET_ID` |
| **SUITE 2: Rejestracja zgłoszeń & Reconciliation Lock Race** | 3 | **PASS (3/3)** | Odczyt komórki pod blokadą bez nadpisywania ID, brak e-maili dla opóźnionych zgłoszeń, zwalnianie blokady <200ms |
| **SUITE 3: Komunikacja i Szablony Awaryjne** | 5 | **PASS (5/5)** | Dynamiczny tekst aktualizacji postępu (brak sztywnego dyspozytora), dedykowane szablony awaryjne (pochwała bez GPS, niekompletne z prośbą o dane, reklamacja z weryfikacją operacyjną), ignorowanie starego szkicu przy błędzie AI |
| **SUITE 4: Priorytety i Robocze SLA (07:00-16:00)** | 4 | **PASS (4/4)** | Okno robocze 7:00-16:00 Pn-Pt (540 min/dzień), weekend startuje w poniedziałek o 7:00, brak fałszywego przeterminowania gdy odpowiedź w terminie, rozróżnienie SLA 1. reakcji od terminu kolejnego działania |
| **SUITE 5: Walidacja danych i Edge Cases** | 7 | **PASS (7/7)** | Odrzucenie "niewiadoma" jako ulicy, brak miejscowości, metale i tworzywa sztuczne (case-insensitive), wykrywanie powtarzalności ("po raz siódmy", "znowu"), obsługa wniosku o kontakt, parser dat (`27,11,26`, `27.11.26`, `27,11,2026`) |
| **SUITE 6: Ochrona danych osobowych (PII)** | 3 | **PASS (3/3)** | Maskowanie imienia, nazwiska, ulicy, telefonu i e-maila w opisie, PII High-Risk Guard (wstrzymanie wysyłki do AI przy wykryciu nr kart/dowodu osobistego), twarda blokada wysyłki poza `wsb.student.tester@gmail.com` |
| **SUITE 7: Warstwa Service API** | 4 | **PASS (4/4)** | Blokada statusu Rozwiązane/Zamknięte bez `resolutionMethod`, brak nadpisywania daty rozwiązania przy kolejnych edycjach, poprawne obiekty Date w `apiGetTicketsList`, zwracanie rzeczywistego stanu i błędów w `apiTriggerAiAnalysis` |
| **ŁĄCZNIE:** | **33** | **PASS (33/33)** | **100% ZALICZONE** |

---

## 6. Procedura weryfikacji manualnej na rzeczywistym koncie Google (`wsb.student.tester@gmail.com`)

> [!IMPORTANT]
> **Rozróżnienie środowisk testowych:**
> - **Testy lokalne (`tests/test-v028-audit.js`):** Wykonywane w środowisku deweloperskim Node.js. Sprawdzają czystą logikę algorytmiczną, kalkulatory terminów SLA, mechanizmy blokad i pre-walidację bez angażowania usług zewnętrznych.
> - **Testy w chmurze Google:** Wykonywane w arkuszu Google powiązanym z kontem `wsb.student.tester@gmail.com`. Weryfikują fizyczne działanie interfejsu użytkownika, menu, wyzwalaczy Apps Script, arkusza oraz wysyłki e-mail.

### Instrukcja wdrożenia i weryfikacji krok po kroku:
1. **Aktualizacja kodu w Google Apps Script:**
   - Otwórz edytor Apps Script z poziomu arkusza CRM (*Rozszerzenia -> Apps Script*).
   - Zastąp zawartość plików `setup.gs`, `ai.gs` i `communication.gs` zaktualizowanym kodem z repozytorium (katalog `google/`).
   - Zapisz projekt (*Ctrl+S*).
2. **Uruchomienie procedury aktualizacji:**
   - Wybierz i uruchom jednorazowo funkcję `updateSystemToV028` lub odśwież arkusz i wybierz z menu *SmartCare -> 🚀 Aktualizuj system do v0.2.8*.
   - Upewnij się, że wyświetlił się komunikat o pomyślnej aktualizacji, a identyfikator arkusza został trwale zapisany w Script Properties.
3. **Weryfikacja wyzwalaczy cyklicznych:**
   - Przejdź do zakładki *Wyzwalacze* (ikona zegara po lewej stronie w edytorze Apps Script).
   - Zweryfikuj, że istnieje **dokładnie jeden** wyzwalacz czasowy `scheduledQueueAndReconcile` z interwałem co 5 minut oraz wyzwalacz formularza `handleNewTicketSubmit`.
4. **Weryfikacja odzyskania pominiętego zgłoszenia:**
   - W arkuszu *ZGŁOSZENIA* sprawdź wiersz z dnia 26.11.2026, 10:42:11 (uszkodzone koło pojemnika w Prokowie).
   - Zgłoszenie powinno posiadać unikalne ID (np. `ELW-2026-0011`), status *Nowe*, priorytet *STANDARDOWY* oraz stan AI *Oczekuje* lub *Gotowa*.
5. **Weryfikacja szablonów i komunikacji:**
   - Zaznacz zgłoszenie będące pochwałą i wybierz *SmartCare -> Przygotuj potwierdzenie przyjęcia*. Upewnij się, że szablon nie zawiera wzmianki o weryfikacji GPS.
   - Wybierz *SmartCare -> Przygotuj aktualizację postępu*. Upewnij się, że treść wiadomości bazuje na notatkach operacyjnych i nie zawiera sztywnej frazy o dyspozytorze.
6. **Weryfikacja ochrony priorytetu pracownika:**
   - Zmień ręcznie priorytet wybranego zgłoszenia na *PILNY*.
   - Uruchom *SmartCare -> Analizuj zgłoszenie przez AI*. Upewnij się, że zatwierdzony przez pracownika priorytet *PILNY* nie został nadpisany przez sugestię AI.
